## Initial codes

* cloned from daattali/beautiful-jekyll
* customized
